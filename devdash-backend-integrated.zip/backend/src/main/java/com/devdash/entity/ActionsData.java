package com.devdash.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "actions_data")
public class ActionsData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repo_id", nullable = false)
    private Repository repository;

    @Column(name = "workflow_name")
    private String workflowName;

    @Column(name = "run_id")
    private Long runId;

    @Enumerated(EnumType.STRING)
    @Column(name = "build_status")
    private BuildStatus buildStatus;

    @Column(name = "branch")
    private String branch;

    @Column(name = "run_time_seconds")
    private Long runTimeSeconds;

    @Column(name = "triggered_by")
    private String triggeredBy;

    @Column(name = "commit_sha", length = 40)
    private String commitSha;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    public enum BuildStatus {
        SUCCESS, FAILURE, IN_PROGRESS, CANCELLED, SKIPPED
    }

    public ActionsData() {}

    public Long getId() { return id; }
    public Repository getRepository() { return repository; }
    public String getWorkflowName() { return workflowName; }
    public Long getRunId() { return runId; }
    public BuildStatus getBuildStatus() { return buildStatus; }
    public String getBranch() { return branch; }
    public Long getRunTimeSeconds() { return runTimeSeconds; }
    public String getTriggeredBy() { return triggeredBy; }
    public String getCommitSha() { return commitSha; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getCompletedAt() { return completedAt; }

    public void setId(Long id) { this.id = id; }
    public void setRepository(Repository repository) { this.repository = repository; }
    public void setWorkflowName(String workflowName) { this.workflowName = workflowName; }
    public void setRunId(Long runId) { this.runId = runId; }
    public void setBuildStatus(BuildStatus buildStatus) { this.buildStatus = buildStatus; }
    public void setBranch(String branch) { this.branch = branch; }
    public void setRunTimeSeconds(Long runTimeSeconds) { this.runTimeSeconds = runTimeSeconds; }
    public void setTriggeredBy(String triggeredBy) { this.triggeredBy = triggeredBy; }
    public void setCommitSha(String commitSha) { this.commitSha = commitSha; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private Repository repository;
        private String workflowName;
        private Long runId;
        private BuildStatus buildStatus;
        private String branch;
        private Long runTimeSeconds;
        private String triggeredBy;
        private String commitSha;
        private LocalDateTime completedAt;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder repository(Repository repository) { this.repository = repository; return this; }
        public Builder workflowName(String workflowName) { this.workflowName = workflowName; return this; }
        public Builder runId(Long runId) { this.runId = runId; return this; }
        public Builder buildStatus(BuildStatus buildStatus) { this.buildStatus = buildStatus; return this; }
        public Builder branch(String branch) { this.branch = branch; return this; }
        public Builder runTimeSeconds(Long runTimeSeconds) { this.runTimeSeconds = runTimeSeconds; return this; }
        public Builder triggeredBy(String triggeredBy) { this.triggeredBy = triggeredBy; return this; }
        public Builder commitSha(String commitSha) { this.commitSha = commitSha; return this; }
        public Builder completedAt(LocalDateTime completedAt) { this.completedAt = completedAt; return this; }

        public ActionsData build() {
            ActionsData a = new ActionsData();
            a.id = id; a.repository = repository; a.workflowName = workflowName;
            a.runId = runId; a.buildStatus = buildStatus; a.branch = branch;
            a.runTimeSeconds = runTimeSeconds; a.triggeredBy = triggeredBy;
            a.commitSha = commitSha; a.completedAt = completedAt;
            return a;
        }
    }
}
