import React, { useState } from 'react'
import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import Navbar from './Navbar'

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div>
      <Sidebar
        collapsed={collapsed}
        mobileOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
      />
      <div className={`main-wrapper${collapsed ? ' collapsed' : ''}`}>
        <Navbar
          onToggleSidebar={() => setCollapsed(!collapsed)}
          onMobileMenu={() => setMobileOpen(!mobileOpen)}
        />
        <div className="main-content">
          <Outlet />
        </div>
      </div>
    </div>
  )
}
