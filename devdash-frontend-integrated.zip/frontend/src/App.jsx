import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider, useAuth } from './context/AuthContext'

import LoginPage from './pages/LoginPage'
import OAuth2Callback from './pages/OAuth2Callback'
import DeveloperDashboard from './pages/developer/DeveloperDashboard'
import DeveloperRepositories from './pages/developer/DeveloperRepositories'
import DeveloperMetrics from './pages/developer/DeveloperMetrics'
import ManagerDashboard from './pages/manager/ManagerDashboard'
import TeamManagement from './pages/manager/TeamManagement'
import DeveloperInsights from './pages/manager/DeveloperInsights'
import ReportsPage from './pages/manager/ReportsPage'
import Layout from './components/layout/Layout'

// ── Route guards ─────────────────────────────────────────────
function RequireAuth({ children, allowedRoles }) {
  const { user, loading } = useAuth()
  if (loading) return <LoadingScreen />
  if (!user) return <Navigate to="/login" replace />
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to={user.role === 'MANAGER' ? '/manager' : '/developer'} replace />
  }
  return children
}

function LoadingScreen() {
  return (
    <div className="loading-overlay">
      <div className="spinner-gradient"></div>
    </div>
  )
}

function AppRoutes() {
  const { user, loading } = useAuth()
  if (loading) return <LoadingScreen />

  const defaultPath = user?.role === 'MANAGER' || user?.role === 'ADMIN' ? '/manager' : '/developer'

  return (
    <Routes>
      {/* Public */}
      <Route
        path="/login"
        element={!user ? <LoginPage /> : <Navigate to={defaultPath} replace />}
      />
      <Route path="/oauth2/callback" element={<OAuth2Callback />} />

      {/* Developer routes */}
      <Route path="/developer" element={
        <RequireAuth allowedRoles={['DEVELOPER', 'MANAGER', 'ADMIN']}>
          <Layout />
        </RequireAuth>
      }>
        <Route index element={<DeveloperDashboard />} />
        <Route path="repositories" element={<DeveloperRepositories />} />
        <Route path="metrics" element={<DeveloperMetrics />} />
      </Route>

      {/* Manager routes */}
      <Route path="/manager" element={
        <RequireAuth allowedRoles={['MANAGER', 'ADMIN']}>
          <Layout />
        </RequireAuth>
      }>
        <Route index element={<ManagerDashboard />} />
        <Route path="teams" element={<TeamManagement />} />
        <Route path="insights" element={<DeveloperInsights />} />
        <Route path="reports" element={<ReportsPage />} />
      </Route>

      {/* Default redirect */}
      <Route path="/" element={<Navigate to={user ? defaultPath : '/login'} replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
        <Toaster position="top-right" toastOptions={{ duration: 3000 }} />
      </Router>
    </AuthProvider>
  )
}
