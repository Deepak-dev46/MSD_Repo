package com.devdash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DevDashApplication {
    public static void main(String[] args) {
        SpringApplication.run(DevDashApplication.class, args);
    }
}
