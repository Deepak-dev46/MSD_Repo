package com.devdash.dto;

import com.devdash.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AuthDto {

    public static class LoginRequest {
        @NotBlank @Email
        private String email;
        @NotBlank @Size(min = 6)
        private String password;

        public LoginRequest() {}
        public String getEmail() { return email; }
        public String getPassword() { return password; }
        public void setEmail(String email) { this.email = email; }
        public void setPassword(String password) { this.password = password; }
    }

    public static class RegisterRequest {
        @NotBlank
        private String name;
        @NotBlank @Email
        private String email;
        @NotBlank @Size(min = 6)
        private String password;
        private User.Role role = User.Role.DEVELOPER;

        public RegisterRequest() {}
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getPassword() { return password; }
        public User.Role getRole() { return role; }
        public void setName(String name) { this.name = name; }
        public void setEmail(String email) { this.email = email; }
        public void setPassword(String password) { this.password = password; }
        public void setRole(User.Role role) { this.role = role; }
    }

    public static class AuthResponse {
        private String token;
        private String refreshToken;
        private String type = "Bearer";
        private Long id;
        private String name;
        private String email;
        private String role;
        private String avatarUrl;
        private String githubUsername;

        public AuthResponse() {}

        public String getToken() { return token; }
        public String getRefreshToken() { return refreshToken; }
        public String getType() { return type; }
        public Long getId() { return id; }
        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getRole() { return role; }
        public String getAvatarUrl() { return avatarUrl; }
        public String getGithubUsername() { return githubUsername; }

        public void setToken(String token) { this.token = token; }
        public void setRefreshToken(String refreshToken) { this.refreshToken = refreshToken; }
        public void setType(String type) { this.type = type; }
        public void setId(Long id) { this.id = id; }
        public void setName(String name) { this.name = name; }
        public void setEmail(String email) { this.email = email; }
        public void setRole(String role) { this.role = role; }
        public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }
        public void setGithubUsername(String githubUsername) { this.githubUsername = githubUsername; }

        public static Builder builder() { return new Builder(); }

        public static class Builder {
            private String token;
            private String refreshToken;
            private Long id;
            private String name;
            private String email;
            private String role;
            private String avatarUrl;
            private String githubUsername;

            public Builder token(String token) { this.token = token; return this; }
            public Builder refreshToken(String refreshToken) { this.refreshToken = refreshToken; return this; }
            public Builder id(Long id) { this.id = id; return this; }
            public Builder name(String name) { this.name = name; return this; }
            public Builder email(String email) { this.email = email; return this; }
            public Builder role(String role) { this.role = role; return this; }
            public Builder avatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; return this; }
            public Builder githubUsername(String githubUsername) { this.githubUsername = githubUsername; return this; }

            public AuthResponse build() {
                AuthResponse r = new AuthResponse();
                r.token = token; r.refreshToken = refreshToken; r.id = id;
                r.name = name; r.email = email; r.role = role;
                r.avatarUrl = avatarUrl; r.githubUsername = githubUsername;
                return r;
            }
        }
    }

    public static class RefreshTokenRequest {
        @NotBlank
        private String refreshToken;

        public RefreshTokenRequest() {}
        public String getRefreshToken() { return refreshToken; }
        public void setRefreshToken(String refreshToken) { this.refreshToken = refreshToken; }
    }
}
