import { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { userApi } from '../services/api'
import toast from 'react-hot-toast'

export default function OAuth2Callback() {
  const [params] = useSearchParams()
  const { login } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    const token = params.get('token')
    const role = params.get('role')

    if (!token) {
      toast.error('GitHub login failed.')
      navigate('/login')
      return
    }

    // Store token first so the API interceptor can use it
    localStorage.setItem('token', token)

    // Fetch full user profile
    userApi.me()
      .then(res => {
        const userData = res.data
        login(userData, token)
        toast.success(`Welcome, ${userData.name}!`)
        navigate(userData.role === 'MANAGER' ? '/manager' : '/developer')
      })
      .catch(() => {
        // Fallback with role from URL
        const userData = { name: 'Developer', role: role || 'DEVELOPER' }
        login(userData, token)
        navigate(role === 'MANAGER' ? '/manager' : '/developer')
      })
  }, [])

  return (
    <div className="loading-overlay">
      <div className="spinner-gradient"></div>
      <p style={{ color: '#fff', marginTop: 20 }}>Completing GitHub login…</p>
    </div>
  )
}
