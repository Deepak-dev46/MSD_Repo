import axios from 'axios'
import toast from 'react-hot-toast'

const API_BASE = '/api'

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' }
})

// Attach JWT token to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
}, err => Promise.reject(err))

// Handle auth errors globally
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    } else if (err.response?.status === 403) {
      toast.error('Access denied.')
    }
    return Promise.reject(err)
  }
)

// ── Auth ──────────────────────────────────────────────────────
export const authApi = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (name, email, password, role) => api.post('/auth/register', { name, email, password, role }),
  refresh: (refreshToken) => api.post('/auth/refresh', { refreshToken }),
  validate: () => api.get('/auth/validate'),
}

// ── Users ─────────────────────────────────────────────────────
export const userApi = {
  me: () => api.get('/users/me'),
  all: () => api.get('/users'),
  developers: () => api.get('/users/developers'),
  leaderboard: () => api.get('/users/leaderboard'),
  atRisk: () => api.get('/users/at-risk'),
  get: (id) => api.get(`/users/${id}`),
  update: (id, data) => api.put(`/users/${id}`, data),
}

// ── Repositories ──────────────────────────────────────────────
export const repoApi = {
  mine: () => api.get('/repos'),
  get: (id) => api.get(`/repos/${id}`),
  stats: (id) => api.get(`/repos/${id}/stats`),
  sync: () => api.post('/repos/sync'),
}

// ── Metrics ───────────────────────────────────────────────────
export const metricsApi = {
  me: () => api.get('/metrics/me'),
  weekly: () => api.get('/metrics/me/weekly'),
  developer: (userId) => api.get(`/metrics/developer/${userId}`),
  team: () => api.get('/metrics/team'),
  leaderboard: () => api.get('/metrics/leaderboard'),
  recalculate: () => api.post('/metrics/recalculate'),
}

// ── Teams ─────────────────────────────────────────────────────
export const teamApi = {
  all: () => api.get('/teams'),
  get: (id) => api.get(`/teams/${id}`),
  create: (data) => api.post('/teams', data),
  update: (id, data) => api.put(`/teams/${id}`, data),
  delete: (id) => api.delete(`/teams/${id}`),
  addMember: (teamId, userId) => api.post(`/teams/${teamId}/members/${userId}`),
  removeMember: (teamId, userId) => api.delete(`/teams/${teamId}/members/${userId}`),
}

export default api
