import React, { useState, useEffect } from 'react'
import { teamApi, userApi } from '../../services/api'
import toast from 'react-hot-toast'

export default function TeamManagement() {
  const [teams, setTeams] = useState([])
  const [developers, setDevelopers] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const [newTeam, setNewTeam] = useState({ name: '', description: '', memberIds: [] })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    Promise.all([teamApi.all(), userApi.developers()])
      .then(([tRes, dRes]) => { setTeams(tRes.data); setDevelopers(dRes.data) })
      .catch(() => toast.error('Failed to load teams'))
      .finally(() => setLoading(false))
  }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    if (!newTeam.name.trim()) return
    setSaving(true)
    try {
      const res = await teamApi.create(newTeam)
      setTeams(prev => [...prev, res.data])
      setNewTeam({ name: '', description: '', memberIds: [] })
      setShowCreate(false)
      toast.success(`Team "${res.data.name}" created!`)
    } catch {
      toast.error('Failed to create team')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id, name) => {
    if (!confirm(`Deactivate team "${name}"?`)) return
    try {
      await teamApi.delete(id)
      setTeams(prev => prev.filter(t => t.id !== id))
      toast.success('Team deactivated')
    } catch {
      toast.error('Failed to delete team')
    }
  }

  const handleRemoveMember = async (teamId, userId, memberName) => {
    try {
      await teamApi.removeMember(teamId, userId)
      setTeams(prev => prev.map(t => t.id === teamId
        ? { ...t, members: t.members.filter(m => m.userId !== userId) }
        : t
      ))
      toast.success(`${memberName} removed from team`)
    } catch {
      toast.error('Failed to remove member')
    }
  }

  const toggleMemberId = (id) => {
    setNewTeam(prev => ({
      ...prev,
      memberIds: prev.memberIds.includes(id)
        ? prev.memberIds.filter(x => x !== id)
        : [...prev.memberIds, id]
    }))
  }

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{ height: '60vh' }}>
      <div className="spinner-border" style={{ color: '#97247E' }} />
    </div>
  )

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Team Management</h1>
            <p className="page-subtitle">{teams.length} active teams · {developers.length} developers</p>
          </div>
          <button className="btn-gradient" onClick={() => setShowCreate(!showCreate)}>
            <i className={`bi bi-${showCreate ? 'x-lg' : 'plus-lg'}`} />
            {showCreate ? 'Cancel' : 'New Team'}
          </button>
        </div>
      </div>

      {/* Create Team Form */}
      {showCreate && (
        <div className="chart-card mb-4" style={{ border: '2px solid rgba(39,35,92,0.15)' }}>
          <div className="chart-card-title mb-4">Create New Team</div>
          <form onSubmit={handleCreate}>
            <div className="row g-3 mb-3">
              <div className="col-md-6">
                <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>Team Name *</label>
                <input
                  className="form-control-custom"
                  placeholder="e.g. Backend Team"
                  value={newTeam.name}
                  onChange={e => setNewTeam({ ...newTeam, name: e.target.value })}
                  required
                />
              </div>
              <div className="col-md-6">
                <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 6, display: 'block' }}>Description</label>
                <input
                  className="form-control-custom"
                  placeholder="Optional description"
                  value={newTeam.description}
                  onChange={e => setNewTeam({ ...newTeam, description: e.target.value })}
                />
              </div>
            </div>
            {developers.length > 0 && (
              <div className="mb-3">
                <label style={{ fontSize: 13, fontWeight: 600, color: '#555', marginBottom: 8, display: 'block' }}>
                  Add Members ({newTeam.memberIds.length} selected)
                </label>
                <div className="d-flex flex-wrap gap-2">
                  {developers.map(dev => (
                    <button
                      key={dev.id}
                      type="button"
                      onClick={() => toggleMemberId(dev.id)}
                      style={{
                        padding: '6px 14px', borderRadius: 20, border: '1.5px solid',
                        borderColor: newTeam.memberIds.includes(dev.id) ? '#27235C' : '#e0e0e0',
                        background: newTeam.memberIds.includes(dev.id) ? 'rgba(39,35,92,0.08)' : 'white',
                        color: newTeam.memberIds.includes(dev.id) ? '#27235C' : '#888',
                        cursor: 'pointer', fontSize: 13, fontWeight: newTeam.memberIds.includes(dev.id) ? 700 : 400
                      }}
                    >
                      {newTeam.memberIds.includes(dev.id) && <i className="bi bi-check2 me-1" />}
                      {dev.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <button type="submit" className="btn-gradient" disabled={saving}>
              {saving ? <><span className="spinner-border spinner-border-sm me-2" />Creating…</> : <><i className="bi bi-plus-circle" />Create Team</>}
            </button>
          </form>
        </div>
      )}

      {/* Teams List */}
      {teams.length === 0 ? (
        <div className="chart-card text-center py-5">
          <i className="bi bi-people" style={{ fontSize: 48, color: '#ddd', display: 'block', marginBottom: 16 }} />
          <p style={{ color: '#aaa' }}>No teams yet. Create your first team above.</p>
        </div>
      ) : (
        <div className="row g-3">
          {teams.map(team => (
            <div key={team.id} className="col-lg-6">
              <div className="chart-card h-100">
                <div className="d-flex justify-content-between align-items-start mb-3">
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 16, color: '#27235C' }}>{team.name}</div>
                    {team.description && <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{team.description}</div>}
                    <div style={{ fontSize: 11, color: '#aaa', marginTop: 4 }}>
                      Manager: {team.managerName} · {team.memberCount ?? 0} members
                    </div>
                  </div>
                  <button
                    onClick={() => handleDelete(team.id, team.name)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#E01950', fontSize: 16, padding: 4 }}
                    title="Deactivate team"
                  >
                    <i className="bi bi-trash3" />
                  </button>
                </div>

                {/* Members */}
                {(team.members || []).length === 0 ? (
                  <p style={{ fontSize: 12, color: '#ccc', textAlign: 'center', padding: '12px 0' }}>No members yet</p>
                ) : (
                  <div className="d-flex flex-wrap gap-2">
                    {team.members.map(m => (
                      <div key={m.userId} style={{
                        display: 'flex', alignItems: 'center', gap: 6,
                        padding: '4px 10px 4px 4px', borderRadius: 20,
                        background: '#f5f5ff', border: '1px solid rgba(39,35,92,0.1)'
                      }}>
                        <div style={{
                          width: 24, height: 24, borderRadius: '50%',
                          background: 'linear-gradient(135deg,#27235C,#97247E)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          color: 'white', fontSize: 10, fontWeight: 700
                        }}>
                          {m.name?.split(' ').map(w => w[0]).join('').slice(0, 2)}
                        </div>
                        <span style={{ fontSize: 12, fontWeight: 600, color: '#27235C' }}>{m.name?.split(' ')[0]}</span>
                        <button
                          onClick={() => handleRemoveMember(team.id, m.userId, m.name)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', fontSize: 12, padding: 0, lineHeight: 1 }}
                        >
                          <i className="bi bi-x" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add existing developer to team */}
                {developers.filter(d => !(team.members || []).some(m => m.userId === d.id)).length > 0 && (
                  <details style={{ marginTop: 12 }}>
                    <summary style={{ fontSize: 12, color: '#97247E', cursor: 'pointer', fontWeight: 600 }}>
                      + Add member
                    </summary>
                    <div className="d-flex flex-wrap gap-2 mt-2">
                      {developers
                        .filter(d => !(team.members || []).some(m => m.userId === d.id))
                        .map(dev => (
                          <button
                            key={dev.id}
                            onClick={async () => {
                              try {
                                await teamApi.addMember(team.id, dev.id)
                                toast.success(`${dev.name} added!`)
                                const res = await teamApi.all()
                                setTeams(res.data)
                              } catch (err) {
                                toast.error(err.response?.data?.error || 'Failed to add member')
                              }
                            }}
                            style={{
                              padding: '4px 12px', borderRadius: 16, border: '1.5px dashed #97247E',
                              background: 'white', color: '#97247E', cursor: 'pointer', fontSize: 12, fontWeight: 600
                            }}
                          >
                            {dev.name}
                          </button>
                        ))}
                    </div>
                  </details>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
