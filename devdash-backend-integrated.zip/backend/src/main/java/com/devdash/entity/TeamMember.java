package com.devdash.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "team_members",
       uniqueConstraints = @UniqueConstraint(columnNames = {"team_id", "user_id"}))
public class TeamMember {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id", nullable = false)
    private Team team;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @CreationTimestamp
    @Column(name = "joined_at", updatable = false)
    private LocalDateTime joinedAt;

    public TeamMember() {}

    public Long getId() { return id; }
    public Team getTeam() { return team; }
    public User getUser() { return user; }
    public LocalDateTime getJoinedAt() { return joinedAt; }

    public void setId(Long id) { this.id = id; }
    public void setTeam(Team team) { this.team = team; }
    public void setUser(User user) { this.user = user; }
    public void setJoinedAt(LocalDateTime joinedAt) { this.joinedAt = joinedAt; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private Team team;
        private User user;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder team(Team team) { this.team = team; return this; }
        public Builder user(User user) { this.user = user; return this; }

        public TeamMember build() {
            TeamMember tm = new TeamMember();
            tm.id = id; tm.team = team; tm.user = user;
            return tm;
        }
    }
}
