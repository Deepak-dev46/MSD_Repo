package com.devdash.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "pull_requests")
public class PullRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repo_id", nullable = false)
    private Repository repository;

    @Column(name = "pr_number")
    private Integer prNumber;

    @Column(name = "title", length = 500)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private PrStatus status;

    @Column(name = "additions")
    private Integer additions = 0;

    @Column(name = "deletions")
    private Integer deletions = 0;

    @Column(name = "changed_files")
    private Integer changedFiles = 0;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id")
    private User author;

    @Column(name = "merged_at")
    private LocalDateTime mergedAt;

    @Column(name = "closed_at")
    private LocalDateTime closedAt;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    public enum PrStatus {
        OPEN, MERGED, CLOSED
    }

    public PullRequest() {}

    public Long getId() { return id; }
    public Repository getRepository() { return repository; }
    public Integer getPrNumber() { return prNumber; }
    public String getTitle() { return title; }
    public PrStatus getStatus() { return status; }
    public Integer getAdditions() { return additions; }
    public Integer getDeletions() { return deletions; }
    public Integer getChangedFiles() { return changedFiles; }
    public User getAuthor() { return author; }
    public LocalDateTime getMergedAt() { return mergedAt; }
    public LocalDateTime getClosedAt() { return closedAt; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setId(Long id) { this.id = id; }
    public void setRepository(Repository repository) { this.repository = repository; }
    public void setPrNumber(Integer prNumber) { this.prNumber = prNumber; }
    public void setTitle(String title) { this.title = title; }
    public void setStatus(PrStatus status) { this.status = status; }
    public void setAdditions(Integer additions) { this.additions = additions; }
    public void setDeletions(Integer deletions) { this.deletions = deletions; }
    public void setChangedFiles(Integer changedFiles) { this.changedFiles = changedFiles; }
    public void setAuthor(User author) { this.author = author; }
    public void setMergedAt(LocalDateTime mergedAt) { this.mergedAt = mergedAt; }
    public void setClosedAt(LocalDateTime closedAt) { this.closedAt = closedAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private Repository repository;
        private Integer prNumber;
        private String title;
        private PrStatus status;
        private Integer additions = 0;
        private Integer deletions = 0;
        private Integer changedFiles = 0;
        private User author;
        private LocalDateTime mergedAt;
        private LocalDateTime closedAt;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder repository(Repository repository) { this.repository = repository; return this; }
        public Builder prNumber(Integer prNumber) { this.prNumber = prNumber; return this; }
        public Builder title(String title) { this.title = title; return this; }
        public Builder status(PrStatus status) { this.status = status; return this; }
        public Builder additions(Integer additions) { this.additions = additions; return this; }
        public Builder deletions(Integer deletions) { this.deletions = deletions; return this; }
        public Builder changedFiles(Integer changedFiles) { this.changedFiles = changedFiles; return this; }
        public Builder author(User author) { this.author = author; return this; }
        public Builder mergedAt(LocalDateTime mergedAt) { this.mergedAt = mergedAt; return this; }
        public Builder closedAt(LocalDateTime closedAt) { this.closedAt = closedAt; return this; }

        public PullRequest build() {
            PullRequest p = new PullRequest();
            p.id = id; p.repository = repository; p.prNumber = prNumber; p.title = title;
            p.status = status; p.additions = additions; p.deletions = deletions;
            p.changedFiles = changedFiles; p.author = author;
            p.mergedAt = mergedAt; p.closedAt = closedAt;
            return p;
        }
    }
}
