import React, { useState, useEffect } from 'react'
import { Bar } from 'react-chartjs-2'
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js'
import { userApi, metricsApi } from '../../services/api'
import toast from 'react-hot-toast'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

export default function DeveloperInsights() {
  const [developers, setDevelopers] = useState([])
  const [selectedDev, setSelectedDev] = useState(null)
  const [devMetrics, setDevMetrics] = useState(null)
  const [loading, setLoading] = useState(true)
  const [loadingMetrics, setLoadingMetrics] = useState(false)

  useEffect(() => {
    userApi.developers()
      .then(r => setDevelopers(r.data))
      .catch(() => toast.error('Failed to load developers'))
      .finally(() => setLoading(false))
  }, [])

  const handleSelectDev = async (dev) => {
    setSelectedDev(dev)
    setLoadingMetrics(true)
    try {
      const res = await metricsApi.developer(dev.id)
      setDevMetrics(res.data)
    } catch {
      toast.error('Failed to load developer metrics')
    } finally {
      setLoadingMetrics(false)
    }
  }

  const getScoreColor = (score) => {
    if (score >= 75) return '#22c55e'
    if (score >= 50) return '#f59e0b'
    return '#E01950'
  }

  const getStatusLabel = (score) => {
    if (score >= 75) return 'High Performer'
    if (score >= 50) return 'Average'
    return 'Needs Support'
  }

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{ height: '60vh' }}>
      <div className="spinner-border" style={{ color: '#97247E' }} />
    </div>
  )

  const weeklyData = devMetrics?.weeklyActivity ? {
    labels: devMetrics.weeklyActivity.map(d => new Date(d.date).toLocaleDateString('en', { weekday: 'short' })),
    datasets: [{
      label: 'Commits',
      data: devMetrics.weeklyActivity.map(d => d.count),
      backgroundColor: '#97247E',
      borderRadius: 8,
    }]
  } : null

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Developer Insights</h1>
        <p className="page-subtitle">Click on a developer to see their detailed metrics.</p>
      </div>

      <div className="row g-3">
        {/* Left: Developer List */}
        <div className="col-lg-4">
          <div className="chart-card" style={{ maxHeight: '80vh', overflowY: 'auto' }}>
            <div className="chart-card-title mb-3">Developers ({developers.length})</div>
            {developers.length === 0 ? (
              <p className="text-muted text-center py-4">No developers found.</p>
            ) : (
              developers.map(dev => {
                const score = dev.productivityScore ?? 0
                const isSelected = selectedDev?.id === dev.id
                return (
                  <div
                    key={dev.id}
                    onClick={() => handleSelectDev(dev)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 12,
                      padding: '12px', borderRadius: 12, cursor: 'pointer',
                      marginBottom: 8,
                      background: isSelected ? 'rgba(39,35,92,0.06)' : 'white',
                      border: isSelected ? '2px solid rgba(39,35,92,0.2)' : '1px solid #f0f0f0',
                      transition: 'all 0.15s'
                    }}
                  >
                    {dev.avatarUrl ? (
                      <img src={dev.avatarUrl} alt={dev.name} style={{ width: 40, height: 40, borderRadius: '50%', objectFit: 'cover' }} />
                    ) : (
                      <div style={{
                        width: 40, height: 40, borderRadius: '50%',
                        background: `linear-gradient(135deg,${getScoreColor(score)}44,${getScoreColor(score)})`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: 'white', fontWeight: 700, fontSize: 14
                      }}>
                        {dev.name?.split(' ').map(w => w[0]).join('').slice(0, 2)}
                      </div>
                    )}
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 13, color: '#27235C' }}>{dev.name}</div>
                      <div style={{ fontSize: 11, color: '#aaa' }}>{dev.githubUsername ? `@${dev.githubUsername}` : dev.email}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontWeight: 800, fontSize: 16, color: getScoreColor(score) }}>{score}</div>
                      <div style={{ fontSize: 10, color: '#aaa' }}>score</div>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </div>

        {/* Right: Metrics Detail */}
        <div className="col-lg-8">
          {!selectedDev ? (
            <div className="chart-card d-flex align-items-center justify-content-center" style={{ height: 400 }}>
              <div style={{ textAlign: 'center' }}>
                <i className="bi bi-person-lines-fill" style={{ fontSize: 48, color: '#ddd', display: 'block', marginBottom: 16 }} />
                <p style={{ color: '#aaa' }}>Select a developer to view their detailed metrics</p>
              </div>
            </div>
          ) : loadingMetrics ? (
            <div className="chart-card d-flex align-items-center justify-content-center" style={{ height: 400 }}>
              <div className="spinner-border" style={{ color: '#97247E' }} />
            </div>
          ) : devMetrics && (
            <>
              {/* Developer header */}
              <div className="chart-card mb-3">
                <div className="d-flex align-items-center gap-3">
                  {selectedDev.avatarUrl ? (
                    <img src={selectedDev.avatarUrl} alt={selectedDev.name} style={{ width: 56, height: 56, borderRadius: '50%' }} />
                  ) : (
                    <div style={{
                      width: 56, height: 56, borderRadius: '50%',
                      background: 'linear-gradient(135deg,#27235C,#97247E)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color: 'white', fontWeight: 700, fontSize: 18
                    }}>
                      {selectedDev.name?.split(' ').map(w => w[0]).join('').slice(0, 2)}
                    </div>
                  )}
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 800, fontSize: 18, color: '#27235C' }}>{devMetrics.name}</div>
                    <div style={{ fontSize: 13, color: '#888' }}>
                      {selectedDev.email}
                      {selectedDev.githubUsername && <span style={{ marginLeft: 8, color: '#97247E' }}>@{selectedDev.githubUsername}</span>}
                    </div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 36, fontWeight: 900, color: getScoreColor(devMetrics.productivityScore ?? 0) }}>
                      {devMetrics.productivityScore ?? 0}
                    </div>
                    <div style={{ fontSize: 12, color: '#aaa' }}>{getStatusLabel(devMetrics.productivityScore ?? 0)}</div>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="row g-3 mb-3">
                {[
                  { label: 'Commits', value: devMetrics.totalCommits ?? 0, icon: 'bi-git', color: '#27235C' },
                  { label: 'Merged PRs', value: devMetrics.mergedPrs ?? 0, icon: 'bi-check2-circle', color: '#22c55e' },
                  { label: 'Open PRs', value: devMetrics.openPrs ?? 0, icon: 'bi-arrow-left-right', color: '#f59e0b' },
                  { label: 'PR Merge Rate', value: `${devMetrics.prMergeRate ?? 0}%`, icon: 'bi-percent', color: '#97247E' },
                ].map(s => (
                  <div key={s.label} className="col-6">
                    <div className="chart-card text-center py-3">
                      <i className={`bi ${s.icon}`} style={{ fontSize: 20, color: s.color, display: 'block', marginBottom: 8 }} />
                      <div style={{ fontWeight: 800, fontSize: 22, color: s.color }}>{s.value}</div>
                      <div style={{ fontSize: 12, color: '#aaa' }}>{s.label}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Weekly chart */}
              {weeklyData && (
                <div className="chart-card">
                  <div className="chart-card-title mb-3">Weekly Commit Activity</div>
                  <div style={{ height: 200 }}>
                    <Bar data={weeklyData} options={{
                      responsive: true, maintainAspectRatio: false,
                      plugins: { legend: { display: false } },
                      scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: '#f5f5f5' } } }
                    }} />
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
