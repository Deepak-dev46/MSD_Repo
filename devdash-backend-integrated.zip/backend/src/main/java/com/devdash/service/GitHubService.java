package com.devdash.service;

import com.devdash.entity.*;
import com.devdash.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class GitHubService {

    private static final Logger log = LoggerFactory.getLogger(GitHubService.class);

    @Value("${github.api.base-url}")
    private String baseUrl;

    @Value("${github.api.token}")
    private String defaultToken;

    @Autowired RepositoryRepository repoRepository;
    @Autowired CommitRepository commitRepository;
    @Autowired PullRequestRepository pullRequestRepository;

    private WebClient buildClient(String token) {
        String bearerToken = (token != null && !token.isBlank()) ? token : defaultToken;
        return WebClient.builder()
                .baseUrl(baseUrl)
                .defaultHeader("Authorization", "Bearer " + bearerToken)
                .defaultHeader("Accept", "application/vnd.github+json")
                .defaultHeader("X-GitHub-Api-Version", "2022-11-28")
                .build();
    }

    // ── Sync all repos for a user ─────────────────────────────
    @SuppressWarnings("unchecked")
    public List<Repository> syncUserRepositories(User user) {
        WebClient client = buildClient(user.getAccessToken());
        List<Map<String, Object>> ghRepos;

        try {
            ghRepos = client.get()
                    .uri("/user/repos?per_page=100&sort=updated")
                    .retrieve()
                    .bodyToMono(List.class)
                    .block();
        } catch (Exception e) {
            log.error("GitHub API error fetching repos: {}", e.getMessage());
            return List.of();
        }

        if (ghRepos == null) return List.of();

        List<Repository> saved = new ArrayList<>();
        for (Map<String, Object> gh : ghRepos) {
            String fullName = (String) gh.get("full_name");
            Repository repo = repoRepository.findByFullName(fullName)
                    .orElse(Repository.builder().user(user).build());

            repo.setRepoName((String) gh.get("name"));
            repo.setFullName(fullName);
            repo.setDescription((String) gh.get("description"));
            repo.setLanguage((String) gh.get("language"));
            repo.setStarsCount((Integer) gh.getOrDefault("stargazers_count", 0));
            repo.setForksCount((Integer) gh.getOrDefault("forks_count", 0));
            repo.setOpenIssuesCount((Integer) gh.getOrDefault("open_issues_count", 0));
            repo.setIsPrivate((Boolean) gh.getOrDefault("private", false));
            repo.setHtmlUrl((String) gh.get("html_url"));

            Object defaultBranch = gh.get("default_branch");
            repo.setDefaultBranch(defaultBranch != null ? defaultBranch.toString() : "main");

            saved.add(repoRepository.save(repo));
        }
        return saved;
    }

    // ── Fetch commits for a repo ─────────────────────────────
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> fetchCommits(String fullName, String token) {
        WebClient client = buildClient(token);
        try {
            return client.get()
                    .uri("/repos/{fullName}/commits?per_page=100", fullName)
                    .retrieve()
                    .bodyToMono(List.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching commits for {}: {}", fullName, e.getMessage());
            return List.of();
        }
    }

    // ── Fetch pull requests ───────────────────────────────────
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> fetchPullRequests(String fullName, String state, String token) {
        WebClient client = buildClient(token);
        try {
            return client.get()
                    .uri("/repos/{fullName}/pulls?state={state}&per_page=100", fullName, state)
                    .retrieve()
                    .bodyToMono(List.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching PRs for {}: {}", fullName, e.getMessage());
            return List.of();
        }
    }

    // ── Fetch GitHub Actions runs ─────────────────────────────
    @SuppressWarnings("unchecked")
    public Map<String, Object> fetchWorkflowRuns(String fullName, String token) {
        WebClient client = buildClient(token);
        try {
            return client.get()
                    .uri("/repos/{fullName}/actions/runs?per_page=30", fullName)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching actions for {}: {}", fullName, e.getMessage());
            return Map.of();
        }
    }

    // ── Fetch GitHub user profile ─────────────────────────────
    @SuppressWarnings("unchecked")
    public Map<String, Object> fetchUserProfile(String token) {
        WebClient client = buildClient(token);
        try {
            return client.get()
                    .uri("/user")
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();
        } catch (Exception e) {
            log.error("Error fetching user profile: {}", e.getMessage());
            return Map.of();
        }
    }
}
