package com.devdash.repository;

import com.devdash.entity.Commit;
import com.devdash.entity.Repository;
import com.devdash.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

@org.springframework.stereotype.Repository
public interface CommitRepository extends JpaRepository<Commit, Long> {

    List<Commit> findByRepository(Repository repository);
    List<Commit> findByAuthor(User author);

    @Query("SELECT c FROM Commit c WHERE c.author = :author AND c.date BETWEEN :start AND :end ORDER BY c.date")
    List<Commit> findByAuthorAndDateRange(@Param("author") User author,
                                          @Param("start") LocalDate start,
                                          @Param("end") LocalDate end);

    @Query("SELECT SUM(c.commitCount) FROM Commit c WHERE c.author = :author")
    Long countTotalCommitsByAuthor(@Param("author") User author);

    @Query("SELECT c.date, SUM(c.commitCount) FROM Commit c WHERE c.author = :author GROUP BY c.date ORDER BY c.date")
    List<Object[]> findDailyCommitCountByAuthor(@Param("author") User author);

    @Query("SELECT SUM(c.additions), SUM(c.deletions) FROM Commit c WHERE c.author = :author")
    Object[] findTotalAdditionsAndDeletionsByAuthor(@Param("author") User author);
}
