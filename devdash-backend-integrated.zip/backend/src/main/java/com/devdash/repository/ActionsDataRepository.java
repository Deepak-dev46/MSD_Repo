package com.devdash.repository;

import com.devdash.entity.ActionsData;
import com.devdash.entity.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

@org.springframework.stereotype.Repository
public interface ActionsDataRepository extends JpaRepository<ActionsData, Long> {
    List<ActionsData> findByRepository(Repository repository);
    List<ActionsData> findByRepositoryOrderByCreatedAtDesc(Repository repository);

    @Query("SELECT a.buildStatus, COUNT(a) FROM ActionsData a WHERE a.repository = :repo GROUP BY a.buildStatus")
    List<Object[]> findBuildStatusCountsByRepo(@Param("repo") Repository repo);

    @Query("SELECT AVG(a.runTimeSeconds) FROM ActionsData a WHERE a.repository = :repo AND a.buildStatus = 'SUCCESS'")
    Double findAvgRunTimeByRepo(@Param("repo") Repository repo);

    List<ActionsData> findTop10ByRepositoryOrderByCreatedAtDesc(Repository repository);
}
