import React, { useState, useEffect } from 'react'
import { Line, Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, BarElement, Title, Tooltip, Legend, Filler
} from 'chart.js'
import { metricsApi } from '../../services/api'
import toast from 'react-hot-toast'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler)

const chartOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
  scales: {
    x: { grid: { display: false }, border: { display: false } },
    y: { grid: { color: '#f5f5f5' }, border: { display: false }, beginAtZero: true }
  }
}

export default function DeveloperMetrics() {
  const [metrics, setMetrics] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    metricsApi.me()
      .then(r => setMetrics(r.data))
      .catch(() => toast.error('Failed to load metrics'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{ height: '60vh' }}>
      <div className="spinner-border" style={{ color: '#97247E' }} />
    </div>
  )

  const weeklyActivity = metrics?.weeklyActivity || []
  const commitChartData = {
    labels: weeklyActivity.map(d => new Date(d.date).toLocaleDateString('en', { weekday: 'short', month: 'short', day: 'numeric' })),
    datasets: [{
      label: 'Commits',
      data: weeklyActivity.map(d => d.count),
      fill: true,
      backgroundColor: 'rgba(151,36,126,0.08)',
      borderColor: '#97247E',
      borderWidth: 2.5,
      pointBackgroundColor: '#97247E',
      pointRadius: 4,
      tension: 0.4,
    }]
  }

  const prBreakdown = {
    labels: ['Merged', 'Open'],
    datasets: [{
      data: [metrics?.mergedPrs ?? 0, metrics?.openPrs ?? 0],
      backgroundColor: ['#27235C', '#97247E'],
      borderRadius: 8,
    }]
  }

  const scoreBreakdown = [
    { label: 'Commit Frequency', value: Math.min(Math.round(((metrics?.totalCommits ?? 0) / 60) * 100), 100), color: '#27235C' },
    { label: 'PR Merge Rate', value: Math.round(metrics?.prMergeRate ?? 0), color: '#97247E' },
    { label: 'Code Volume', value: Math.min(Math.round(((metrics?.totalAdditions ?? 0) / 5000) * 100), 100), color: '#E01950' },
    { label: 'Active Repos', value: Math.min(Math.round(((metrics?.repositories ?? 0) / 10) * 100), 100), color: '#22c55e' },
  ]

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">My Metrics</h1>
        <p className="page-subtitle">Detailed performance analytics for your coding activity.</p>
      </div>

      {/* Summary Stats */}
      <div className="row g-3 mb-4">
        {[
          { label: 'Total Commits', value: metrics?.totalCommits ?? 0, icon: 'bi-git', color: '#27235C' },
          { label: 'Merged PRs', value: metrics?.mergedPrs ?? 0, icon: 'bi-check2-circle', color: '#22c55e' },
          { label: 'Lines Added', value: (metrics?.totalAdditions ?? 0).toLocaleString(), icon: 'bi-plus-circle', color: '#3b82f6' },
          { label: 'Lines Deleted', value: (metrics?.totalDeletions ?? 0).toLocaleString(), icon: 'bi-dash-circle', color: '#E01950' },
        ].map((stat, i) => (
          <div key={stat.label} className="col-lg-3 col-sm-6">
            <div className="chart-card text-center">
              <div style={{
                width: 48, height: 48, borderRadius: 14, margin: '0 auto 12px',
                background: `${stat.color}15`,
                display: 'flex', alignItems: 'center', justifyContent: 'center'
              }}>
                <i className={`bi ${stat.icon}`} style={{ fontSize: 22, color: stat.color }} />
              </div>
              <div style={{ fontSize: 26, fontWeight: 800, color: stat.color }}>{stat.value}</div>
              <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="row g-3 mb-4">
        <div className="col-lg-8">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Commit Activity (Last 7 Days)</div>
                <div className="chart-card-sub">Daily commit count</div>
              </div>
            </div>
            <div style={{ height: 250 }}>
              {weeklyActivity.length > 0
                ? <Line data={commitChartData} options={chartOpts} />
                : <div className="d-flex align-items-center justify-content-center h-100 text-muted">Sync GitHub to load commit data.</div>
              }
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">PR Summary</div>
                <div className="chart-card-sub">Merged vs Open</div>
              </div>
            </div>
            <div style={{ height: 250 }}>
              <Bar data={prBreakdown} options={{ ...chartOpts, plugins: { ...chartOpts.plugins, legend: { display: true, position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } } }} />
            </div>
          </div>
        </div>
      </div>

      {/* Score breakdown */}
      <div className="row g-3">
        <div className="col-lg-6">
          <div className="chart-card">
            <div className="chart-card-title mb-4">Productivity Score Breakdown</div>
            {scoreBreakdown.map(item => (
              <div key={item.label} className="mb-3">
                <div className="d-flex justify-content-between mb-1">
                  <span style={{ fontSize: 13, color: '#555' }}>{item.label}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}%</span>
                </div>
                <div className="progress-custom">
                  <div className="progress-fill" style={{ width: `${item.value}%`, background: `linear-gradient(90deg,${item.color}88,${item.color})` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="col-lg-6">
          <div className="chart-card">
            <div className="chart-card-title mb-4">Overall Productivity Score</div>
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <div style={{
                fontSize: 80, fontWeight: 900,
                background: 'linear-gradient(135deg,#27235C,#97247E)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'
              }}>
                {metrics?.productivityScore ?? 0}
              </div>
              <div style={{ fontSize: 16, color: '#888', marginTop: 8 }}>out of 100</div>
              <div style={{ marginTop: 20 }}>
                <div className="progress-custom" style={{ height: 16, borderRadius: 8 }}>
                  <div className="progress-fill" style={{
                    width: `${metrics?.productivityScore ?? 0}%`,
                    background: 'linear-gradient(90deg,#27235C,#97247E)',
                    height: '100%', borderRadius: 8
                  }} />
                </div>
              </div>
              <div style={{ marginTop: 16, padding: '12px', background: '#f8f9ff', borderRadius: 10 }}>
                <div style={{ fontSize: 13, color: '#666' }}>
                  PR Merge Rate: <strong style={{ color: '#27235C' }}>{metrics?.prMergeRate ?? 0}%</strong>
                  {' · '}
                  Open PRs: <strong style={{ color: '#97247E' }}>{metrics?.openPrs ?? 0}</strong>
                  {' · '}
                  Repos: <strong style={{ color: '#E01950' }}>{metrics?.repositories ?? 0}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
