import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

export default function Navbar({ onToggleSidebar, onMobileMenu }) {
  const { user, darkMode, setDarkMode, logout } = useAuth()
  const [showProfile, setShowProfile] = useState(false)
  const navigate = useNavigate()

  const initials = user?.name?.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) || 'U'

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="top-navbar">
      <div className="d-flex align-items-center gap-3">
        <button className="nav-icon-btn d-lg-flex d-none" onClick={onToggleSidebar}>
          <i className="bi bi-layout-sidebar" />
        </button>
        <button className="nav-icon-btn d-lg-none" onClick={onMobileMenu}>
          <i className="bi bi-list" />
        </button>
        <div className="navbar-search">
          <i className="bi bi-search" style={{ color: '#aaa', fontSize: 14 }} />
          <input placeholder="Search repos, commits..." />
        </div>
      </div>

      <div className="d-flex align-items-center gap-2">
        {/* Dark mode */}
        <button className="nav-icon-btn" onClick={() => setDarkMode(!darkMode)} title="Toggle dark mode">
          <i className={`bi ${darkMode ? 'bi-sun' : 'bi-moon'}`} />
        </button>

        {/* Profile dropdown */}
        <div style={{ position: 'relative' }}>
          <button
            className="d-flex align-items-center gap-2 border-0 bg-transparent"
            style={{ cursor: 'pointer', padding: '4px 8px', borderRadius: 10 }}
            onClick={() => setShowProfile(!showProfile)}
          >
            {user?.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={user.name}
                style={{ width: 34, height: 34, borderRadius: '50%', objectFit: 'cover' }}
              />
            ) : (
              <div style={{
                width: 34, height: 34, borderRadius: '50%',
                background: 'linear-gradient(135deg,#27235C,#97247E)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'white', fontSize: 13, fontWeight: 700
              }}>
                {initials}
              </div>
            )}
            <div className="d-none d-md-block" style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#27235C' }}>{user?.name}</div>
              <div style={{ fontSize: 11, color: '#aaa' }}>{user?.role}</div>
            </div>
            <i className="bi bi-chevron-down" style={{ fontSize: 11, color: '#aaa' }} />
          </button>

          {showProfile && (
            <div style={{
              position: 'absolute', right: 0, top: '110%',
              background: 'white', borderRadius: 14, padding: '8px',
              boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
              border: '1px solid rgba(0,0,0,0.06)', minWidth: 180, zIndex: 1000
            }}>
              <div style={{ padding: '8px 12px', borderBottom: '1px solid #f0f0f0', marginBottom: 4 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#27235C' }}>{user?.name}</div>
                <div style={{ fontSize: 11, color: '#aaa' }}>{user?.email}</div>
              </div>
              <button
                onClick={handleLogout}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  width: '100%', padding: '8px 12px', border: 'none',
                  background: 'none', borderRadius: 8, cursor: 'pointer',
                  fontSize: 13, color: '#E01950', fontWeight: 600
                }}
              >
                <i className="bi bi-box-arrow-left" />
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
