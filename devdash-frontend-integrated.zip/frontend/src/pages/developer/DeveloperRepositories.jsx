import React, { useState, useEffect } from 'react'
import { repoApi } from '../../services/api'
import toast from 'react-hot-toast'

const langColors = {
  Java: '#b07219', TypeScript: '#3178c6', JavaScript: '#f1e05a',
  Python: '#3572A5', Kotlin: '#A97BFF', YAML: '#cb171e',
  Go: '#00ADD8', Ruby: '#CC342D', 'C#': '#178600', Rust: '#dea584'
}

export default function DeveloperRepositories() {
  const [repos, setRepos] = useState([])
  const [loading, setLoading] = useState(true)
  const [syncing, setSyncing] = useState(false)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')

  useEffect(() => { fetchRepos() }, [])

  const fetchRepos = async () => {
    setLoading(true)
    try {
      const res = await repoApi.mine()
      setRepos(res.data)
    } catch {
      toast.error('Failed to load repositories')
    } finally {
      setLoading(false)
    }
  }

  const handleSync = async () => {
    setSyncing(true)
    try {
      const res = await repoApi.sync()
      toast.success(`Synced ${res.data.count} repositories!`)
      fetchRepos()
    } catch {
      toast.error('Sync failed. Check GitHub access token.')
    } finally {
      setSyncing(false)
    }
  }

  const filtered = repos.filter(r => {
    const matchSearch = r.repoName?.toLowerCase().includes(search.toLowerCase())
      || r.fullName?.toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === 'all'
      || (filter === 'public' && !r.isPrivate)
      || (filter === 'private' && r.isPrivate)
    return matchSearch && matchFilter
  })

  const publicCount = repos.filter(r => !r.isPrivate).length

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Repositories</h1>
            <p className="page-subtitle">{repos.length} repositories · {publicCount} public</p>
          </div>
          <div className="d-flex gap-2">
            <button className="btn-gradient" onClick={handleSync} disabled={syncing}>
              <i className={`bi bi-arrow-clockwise${syncing ? ' spin' : ''}`} />
              {syncing ? 'Syncing…' : 'Sync from GitHub'}
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="chart-card mb-4">
        <div className="d-flex flex-wrap gap-3 align-items-center">
          <div style={{ position: 'relative', flex: '1 1 200px' }}>
            <i className="bi bi-search" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#aaa' }} />
            <input
              className="form-control-custom"
              style={{ paddingLeft: 38 }}
              placeholder="Search repositories…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="d-flex gap-2 flex-wrap">
            {['all', 'public', 'private'].map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={filter === f ? 'btn-gradient' : ''}
                style={filter !== f ? {
                  padding: '8px 16px', borderRadius: 10, border: '1px solid #e0e0e0',
                  background: 'white', cursor: 'pointer', fontSize: 13, color: '#555', fontWeight: 500
                } : { fontSize: 13 }}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="d-flex align-items-center justify-content-center" style={{ height: 300 }}>
          <div className="spinner-border" style={{ color: '#97247E' }} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="chart-card text-center py-5">
          <i className="bi bi-folder2-open" style={{ fontSize: 48, color: '#ddd', display: 'block', marginBottom: 16 }} />
          <p style={{ color: '#aaa', fontSize: 15 }}>
            {repos.length === 0 ? 'No repositories yet. Click "Sync from GitHub" to import yours.' : 'No repositories match your search.'}
          </p>
        </div>
      ) : (
        <div className="row g-3">
          {filtered.map(repo => (
            <div key={repo.id} className="col-lg-6">
              <div className="chart-card h-100" style={{ cursor: 'pointer', transition: 'transform 0.15s' }}
                onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'none'}
              >
                <div className="d-flex align-items-start justify-content-between mb-3">
                  <div className="d-flex align-items-center gap-2">
                    <div style={{
                      width: 36, height: 36, borderRadius: 10,
                      background: 'linear-gradient(135deg,rgba(39,35,92,0.1),rgba(151,36,126,0.1))',
                      display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}>
                      <i className="bi bi-folder-fill" style={{ color: '#97247E', fontSize: 16 }} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14, color: '#27235C' }}>
                        {repo.repoName}
                      </div>
                      <div style={{ fontSize: 11, color: '#aaa' }}>{repo.fullName}</div>
                    </div>
                  </div>
                  <div className="d-flex gap-1 align-items-center">
                    <span className={`status-badge ${repo.isPrivate ? 'warning' : 'success'}`}>
                      <i className={`bi bi-${repo.isPrivate ? 'lock' : 'globe'}`} />
                      {repo.isPrivate ? 'Private' : 'Public'}
                    </span>
                  </div>
                </div>

                {repo.description && (
                  <p style={{ fontSize: 12, color: '#888', marginBottom: 12, lineHeight: 1.5 }}>
                    {repo.description.length > 100 ? repo.description.slice(0, 100) + '…' : repo.description}
                  </p>
                )}

                <div className="d-flex align-items-center gap-3 flex-wrap" style={{ fontSize: 12 }}>
                  {repo.language && (
                    <span className="d-flex align-items-center gap-1">
                      <span style={{
                        width: 10, height: 10, borderRadius: '50%',
                        background: langColors[repo.language] || '#888', display: 'inline-block'
                      }} />
                      <span style={{ color: '#666' }}>{repo.language}</span>
                    </span>
                  )}
                  <span style={{ color: '#888' }}>
                    <i className="bi bi-star me-1" />
                    {repo.starsCount ?? 0}
                  </span>
                  <span style={{ color: '#888' }}>
                    <i className="bi bi-diagram-2 me-1" />
                    {repo.forksCount ?? 0}
                  </span>
                  <span style={{ color: '#888' }}>
                    <i className="bi bi-exclamation-circle me-1" />
                    {repo.openIssuesCount ?? 0} issues
                  </span>
                </div>

                {repo.htmlUrl && (
                  <a
                    href={repo.htmlUrl}
                    target="_blank"
                    rel="noreferrer"
                    style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 10, fontSize: 12, color: '#97247E', textDecoration: 'none', fontWeight: 600 }}
                  >
                    <i className="bi bi-box-arrow-up-right" /> View on GitHub
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
