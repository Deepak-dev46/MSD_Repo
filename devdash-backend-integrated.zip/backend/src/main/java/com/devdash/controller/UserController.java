package com.devdash.controller;

import com.devdash.entity.User;
import com.devdash.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired UserRepository userRepository;
    @Autowired PasswordEncoder encoder;

    // GET /api/users/me
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(toDto(user));
    }

    // GET /api/users  (managers only)
    @GetMapping
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<List<Map<String, Object>>> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll().stream().map(this::toDto).toList());
    }

    // GET /api/users/developers
    @GetMapping("/developers")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> getDevelopers() {
        List<User> devs = userRepository.findByRole(User.Role.DEVELOPER);
        return ResponseEntity.ok(devs.stream().map(this::toDto).toList());
    }

    // GET /api/users/leaderboard
    @GetMapping("/leaderboard")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> getLeaderboard() {
        return ResponseEntity.ok(userRepository.findTopDevelopersByScore().stream().map(this::toDto).toList());
    }

    // GET /api/users/at-risk
    @GetMapping("/at-risk")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public ResponseEntity<?> getAtRiskDevelopers() {
        return ResponseEntity.ok(userRepository.findLowPerformingDevelopers().stream().map(this::toDto).toList());
    }

    // GET /api/users/{id}
    @GetMapping("/{id}")
    public ResponseEntity<?> getUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(u -> ResponseEntity.ok(toDto(u)))
                .orElse(ResponseEntity.notFound().build());
    }

    // PUT /api/users/{id}
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id,
                                        @RequestBody Map<String, String> body,
                                        Authentication auth) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Ensure users can only update themselves unless admin
        User current = userRepository.findByEmail(auth.getName()).orElseThrow();
        if (!current.getId().equals(id) && current.getRole() != User.Role.ADMIN) {
            return ResponseEntity.status(403).body(Map.of("error", "Forbidden"));
        }

        if (body.containsKey("name")) user.setName(body.get("name"));
        if (body.containsKey("password")) user.setPassword(encoder.encode(body.get("password")));

        userRepository.save(user);
        return ResponseEntity.ok(toDto(user));
    }

    // DELETE /api/users/{id}
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "User deleted"));
    }

    private Map<String, Object> toDto(User u) {
        return Map.of(
            "id", u.getId(),
            "name", u.getName(),
            "email", u.getEmail(),
            "role", u.getRole().name(),
            "githubUsername", u.getGithubUsername() != null ? u.getGithubUsername() : "",
            "avatarUrl", u.getAvatarUrl() != null ? u.getAvatarUrl() : "",
            "productivityScore", u.getProductivityScore() != null ? u.getProductivityScore() : 0,
            "isActive", u.getIsActive()
        );
    }
}
