import React, { useState, useEffect } from 'react'
import { Line, Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement,
  LineElement, BarElement, Title, Tooltip, Legend, Filler
} from 'chart.js'
import { useAuth } from '../../context/AuthContext'
import { metricsApi, repoApi } from '../../services/api'
import toast from 'react-hot-toast'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler)

const chartOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
  scales: {
    x: { grid: { display: false }, border: { display: false } },
    y: { grid: { color: '#f5f5f5' }, border: { display: false } }
  }
}

export default function DeveloperDashboard() {
  const { user } = useAuth()
  const [metrics, setMetrics] = useState(null)
  const [weekly, setWeekly] = useState([])
  const [loading, setLoading] = useState(true)
  const [syncing, setSyncing] = useState(false)
  const [animateKpi, setAnimateKpi] = useState(false)

  useEffect(() => {
    fetchData()
  }, [])

  useEffect(() => {
    if (!loading) setTimeout(() => setAnimateKpi(true), 100)
  }, [loading])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [mRes, wRes] = await Promise.all([metricsApi.me(), metricsApi.weekly()])
      setMetrics(mRes.data)
      setWeekly(wRes.data)
    } catch (err) {
      toast.error('Failed to load metrics')
    } finally {
      setLoading(false)
    }
  }

  const handleSync = async () => {
    setSyncing(true)
    try {
      await repoApi.sync()
      toast.success('GitHub sync complete!')
      fetchData()
    } catch {
      toast.error('Sync failed. Check GitHub token.')
    } finally {
      setSyncing(false)
    }
  }

  const kpis = metrics ? [
    { label: 'Total Commits', value: metrics.totalCommits ?? 0, icon: 'bi-git', color: 'blue', trend: '+12%', sub: 'All time' },
    { label: 'Pull Requests', value: metrics.totalPrs ?? 0, icon: 'bi-arrow-left-right', color: 'purple', trend: `${metrics.mergedPrs ?? 0} merged`, sub: 'Total PRs' },
    { label: 'PR Merge Rate', value: `${metrics.prMergeRate ?? 0}%`, icon: 'bi-check2-circle', color: 'green', trend: `${metrics.mergedPrs ?? 0} merged`, sub: 'Of all PRs' },
    { label: 'Productivity Score', value: metrics.productivityScore ?? 0, icon: 'bi-lightning-charge-fill', color: 'red', trend: 'Score', sub: 'Out of 100' },
  ] : []

  const weeklyChartData = {
    labels: weekly.map(d => {
      const dt = new Date(d.date)
      return dt.toLocaleDateString('en', { weekday: 'short' })
    }),
    datasets: [{
      label: 'Commits',
      data: weekly.map(d => d.count),
      fill: true,
      backgroundColor: 'rgba(151,36,126,0.08)',
      borderColor: '#97247E',
      borderWidth: 2.5,
      pointBackgroundColor: '#97247E',
      pointRadius: 4,
      tension: 0.4,
    }]
  }

  const prChartData = {
    labels: ['Merged', 'Open', 'Closed'],
    datasets: [{
      data: [metrics?.mergedPrs ?? 0, metrics?.openPrs ?? 0, 0],
      backgroundColor: ['#27235C', '#97247E', '#E01950'],
      borderRadius: 8,
    }]
  }

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{ height: '60vh' }}>
      <div className="spinner-border" style={{ color: '#97247E' }} />
    </div>
  )

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Good morning, {user?.name?.split(' ')[0] || 'Developer'} 👋</h1>
            <p className="page-subtitle">Here's what's happening with your code today.</p>
          </div>
          <div className="d-flex gap-2">
            <button className="btn-gradient" onClick={handleSync} disabled={syncing}>
              <i className={`bi ${syncing ? 'bi-arrow-clockwise spin' : 'bi-arrow-clockwise'}`} />
              {syncing ? 'Syncing…' : 'Sync GitHub'}
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="row g-3 mb-4">
        {kpis.map((kpi, i) => (
          <div key={kpi.label} className="col-lg-3 col-sm-6">
            <div className="kpi-card" style={{
              opacity: animateKpi ? 1 : 0,
              transform: animateKpi ? 'none' : 'translateY(20px)',
              transition: `all 0.5s ${i * 0.1}s`
            }}>
              <div className={`kpi-icon ${kpi.color}`}>
                <i className={`bi ${kpi.icon}`} />
              </div>
              <div className="kpi-value">{kpi.value}</div>
              <div className="kpi-label">{kpi.label}</div>
              <div className="d-flex align-items-center justify-content-between mt-2">
                <span className="kpi-trend up">
                  <i className="bi bi-arrow-up" />{kpi.trend}
                </span>
                <span style={{ fontSize: 11, color: '#bbb' }}>{kpi.sub}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="row g-3 mb-4">
        <div className="col-lg-8">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Weekly Commit Activity</div>
                <div className="chart-card-sub">Last 7 days across all repositories</div>
              </div>
            </div>
            <div style={{ height: 240 }}>
              {weekly.length > 0
                ? <Line data={weeklyChartData} options={chartOpts} />
                : <div className="d-flex align-items-center justify-content-center h-100 text-muted">No commit data yet. Sync GitHub to load data.</div>
              }
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">PR Status</div>
                <div className="chart-card-sub">Merged vs Open</div>
              </div>
            </div>
            <div style={{ height: 240 }}>
              <Bar data={prChartData} options={{ ...chartOpts, plugins: { ...chartOpts.plugins, legend: { display: true, position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } } }} />
            </div>
          </div>
        </div>
      </div>

      {/* Productivity Breakdown */}
      {metrics && (
        <div className="row g-3">
          <div className="col-lg-5">
            <div className="chart-card">
              <div className="chart-card-title mb-4">Code Stats</div>
              {[
                { label: 'Lines Added', value: metrics.totalAdditions ?? 0, color: '#27235C', format: n => n.toLocaleString() },
                { label: 'Lines Deleted', value: metrics.totalDeletions ?? 0, color: '#E01950', format: n => n.toLocaleString() },
                { label: 'Repositories', value: metrics.repositories ?? 0, color: '#97247E', format: n => n },
                { label: 'Open PRs', value: metrics.openPrs ?? 0, color: '#f59e0b', format: n => n },
              ].map(item => (
                <div key={item.label} className="d-flex justify-content-between align-items-center mb-3 pb-2" style={{ borderBottom: '1px solid #f5f5f5' }}>
                  <span style={{ fontSize: 13, color: '#555' }}>{item.label}</span>
                  <span style={{ fontSize: 15, fontWeight: 700, color: item.color }}>{item.format(item.value)}</span>
                </div>
              ))}

              <div style={{ marginTop: 20, padding: '16px', background: 'linear-gradient(135deg,rgba(39,35,92,0.05),rgba(151,36,126,0.05))', borderRadius: 12 }}>
                <div style={{ fontSize: 13, color: '#888', marginBottom: 4 }}>Overall Score</div>
                <div style={{ fontSize: 40, fontWeight: 900, background: 'linear-gradient(135deg,#27235C,#97247E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                  {metrics.productivityScore ?? 0}
                </div>
                <div style={{ fontSize: 12, color: '#aaa' }}>Out of 100</div>
              </div>
            </div>
          </div>
          <div className="col-lg-7">
            <div className="chart-card">
              <div className="chart-card-header">
                <div className="chart-card-title">Productivity Breakdown</div>
              </div>
              {[
                { label: 'Commit Frequency', value: Math.min(Math.round((metrics.totalCommits / 60) * 100), 100), color: '#27235C' },
                { label: 'PR Merge Rate', value: Math.round(metrics.prMergeRate ?? 0), color: '#97247E' },
                { label: 'Code Volume', value: Math.min(Math.round(((metrics.totalAdditions ?? 0) / 5000) * 100), 100), color: '#E01950' },
                { label: 'Active Repos', value: Math.min(Math.round(((metrics.repositories ?? 0) / 10) * 100), 100), color: '#22c55e' },
              ].map(item => (
                <div key={item.label} className="mb-3">
                  <div className="d-flex justify-content-between mb-1">
                    <span style={{ fontSize: 13, color: '#555' }}>{item.label}</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: item.color }}>{item.value}%</span>
                  </div>
                  <div className="progress-custom">
                    <div className="progress-fill" style={{ width: `${item.value}%`, background: `linear-gradient(90deg,${item.color}88,${item.color})` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
