package com.devdash.config;

import com.devdash.entity.User;
import com.devdash.repository.UserRepository;
import com.devdash.security.JwtUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class OAuth2SuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    @Autowired UserRepository userRepository;
    @Autowired JwtUtils jwtUtils;

    @Value("${app.frontend.url}")
    private String frontendUrl;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException {
        OAuth2User oAuth2User = (OAuth2User) authentication.getPrincipal();

        String githubId       = String.valueOf(oAuth2User.getAttribute("id"));
        String login          = oAuth2User.getAttribute("login");
        String name           = oAuth2User.getAttribute("name");
        String email          = oAuth2User.getAttribute("email");
        String avatarUrl      = oAuth2User.getAttribute("avatar_url");

        if (email == null || email.isBlank()) {
            email = login + "@github.com";  // fallback
        }
        final String finalEmail = email;

        User user = userRepository.findByGithubId(githubId).orElseGet(() ->
            userRepository.findByEmail(finalEmail).orElse(null)
        );

        if (user == null) {
            user = User.builder()
                    .name(name != null ? name : login)
                    .email(finalEmail)
                    .githubId(githubId)
                    .githubUsername(login)
                    .avatarUrl(avatarUrl)
                    .role(User.Role.DEVELOPER)
                    .isActive(true)
                    .build();
        } else {
            user.setGithubId(githubId);
            user.setGithubUsername(login);
            if (avatarUrl != null) user.setAvatarUrl(avatarUrl);
        }

        userRepository.save(user);

        String jwt = jwtUtils.generateTokenFromUsername(user.getEmail());
        String redirectUrl = frontendUrl + "/oauth2/callback?token=" + jwt
                + "&role=" + user.getRole().name();

        getRedirectStrategy().sendRedirect(request, response, redirectUrl);
    }
}
