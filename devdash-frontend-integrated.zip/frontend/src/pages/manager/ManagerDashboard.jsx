import React, { useState, useEffect } from 'react'
import { Bar, Pie } from 'react-chartjs-2'
import { Chart as ChartJS, ArcElement, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js'
import { metricsApi, userApi } from '../../services/api'
import { useAuth } from '../../context/AuthContext'
import toast from 'react-hot-toast'

ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

const chartOpts = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { display: false }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
  scales: { x: { grid: { display: false }, border: { display: false } }, y: { grid: { color: '#f5f5f5' }, border: { display: false } } }
}

export default function ManagerDashboard() {
  const { user } = useAuth()
  const [teamMetrics, setTeamMetrics] = useState(null)
  const [leaderboard, setLeaderboard] = useState([])
  const [atRisk, setAtRisk] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      metricsApi.team(),
      metricsApi.leaderboard(),
      userApi.atRisk()
    ]).then(([tRes, lRes, rRes]) => {
      setTeamMetrics(tRes.data)
      setLeaderboard(lRes.data)
      setAtRisk(rRes.data)
    }).catch(() => toast.error('Failed to load team data'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{ height: '60vh' }}>
      <div className="spinner-border" style={{ color: '#97247E' }} />
    </div>
  )

  const devs = teamMetrics?.developers || []

  const prodBarData = {
    labels: devs.slice(0, 8).map(d => d.name?.split(' ')[0]),
    datasets: [{
      label: 'Score',
      data: devs.slice(0, 8).map(d => d.score),
      backgroundColor: devs.slice(0, 8).map(d => d.score < 50 ? '#E01950' : d.score < 75 ? '#f59e0b' : '#27235C'),
      borderRadius: 10,
    }]
  }

  const contribData = {
    labels: devs.slice(0, 6).map(d => d.name?.split(' ')[0]),
    datasets: [{
      data: devs.slice(0, 6).map(d => d.commits),
      backgroundColor: ['#27235C', '#97247E', '#E01950', '#f59e0b', '#22c55e', '#3b82f6'],
      borderWidth: 0,
    }]
  }

  const kpis = [
    { label: 'Total Developers', value: teamMetrics?.totalDevelopers ?? 0, icon: 'bi-people', color: 'blue' },
    { label: 'Active Developers', value: teamMetrics?.activeDevelopers ?? 0, icon: 'bi-person-check', color: 'green' },
    { label: 'Total Commits', value: teamMetrics?.totalCommits ?? 0, icon: 'bi-git', color: 'purple' },
    { label: 'At Risk', value: teamMetrics?.atRiskCount ?? 0, icon: 'bi-exclamation-triangle', color: 'red' },
  ]

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Team Overview 🎯</h1>
            <p className="page-subtitle">Welcome back, {user?.name?.split(' ')[0]}. Here's your team's performance.</p>
          </div>
          <button className="btn-gradient" onClick={() => { metricsApi.recalculate(); toast.success('Recalculating scores…') }}>
            <i className="bi bi-arrow-clockwise" /> Recalculate Scores
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="row g-3 mb-4">
        {kpis.map((kpi, i) => (
          <div key={kpi.label} className="col-lg-3 col-sm-6">
            <div className="kpi-card">
              <div className={`kpi-icon ${kpi.color}`}><i className={`bi ${kpi.icon}`} /></div>
              <div className="kpi-value">{kpi.value}</div>
              <div className="kpi-label">{kpi.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="row g-3 mb-4">
        <div className="col-lg-7">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Productivity Scores</div>
                <div className="chart-card-sub">Per developer · Red = at risk</div>
              </div>
            </div>
            <div style={{ height: 260 }}>
              {devs.length > 0
                ? <Bar data={prodBarData} options={chartOpts} />
                : <div className="d-flex align-items-center justify-content-center h-100 text-muted">No developer data yet.</div>
              }
            </div>
          </div>
        </div>
        <div className="col-lg-5">
          <div className="chart-card">
            <div className="chart-card-header">
              <div>
                <div className="chart-card-title">Commit Contribution</div>
                <div className="chart-card-sub">Share by developer</div>
              </div>
            </div>
            <div style={{ height: 260 }}>
              {devs.length > 0
                ? <Pie data={contribData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right', labels: { boxWidth: 10, font: { size: 11 } } } } }} />
                : <div className="d-flex align-items-center justify-content-center h-100 text-muted">No data.</div>
              }
            </div>
          </div>
        </div>
      </div>

      {/* Team table + at risk */}
      <div className="row g-3">
        <div className="col-lg-8">
          <div className="chart-card">
            <div className="chart-card-header mb-3">
              <div className="chart-card-title">Team Members</div>
            </div>
            {devs.length === 0 ? (
              <p className="text-muted text-center py-4">No developers found. Register developer accounts to populate this list.</p>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: '2px solid #f0f0f0' }}>
                      {['Developer', 'Commits', 'PRs', 'Score', 'Status'].map(h => (
                        <th key={h} style={{ padding: '8px 12px', textAlign: 'left', color: '#aaa', fontWeight: 600, fontSize: 12 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {devs.map(dev => {
                      const score = dev.score ?? 0
                      const status = score >= 75 ? 'success' : score >= 50 ? 'warning' : 'danger'
                      const statusLabel = score >= 75 ? 'Active' : score >= 50 ? 'Average' : 'At Risk'
                      return (
                        <tr key={dev.id} style={{ borderBottom: '1px solid #f8f8f8' }}>
                          <td style={{ padding: '10px 12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                              <div style={{
                                width: 32, height: 32, borderRadius: '50%',
                                background: 'linear-gradient(135deg,#27235C,#97247E)',
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                color: 'white', fontSize: 12, fontWeight: 700
                              }}>
                                {dev.name?.split(' ').map(w => w[0]).join('').slice(0, 2)}
                              </div>
                              <span style={{ fontWeight: 600, color: '#27235C' }}>{dev.name}</span>
                            </div>
                          </td>
                          <td style={{ padding: '10px 12px', color: '#555' }}>{dev.commits}</td>
                          <td style={{ padding: '10px 12px', color: '#555' }}>{dev.prs}</td>
                          <td style={{ padding: '10px 12px' }}>
                            <span style={{ fontWeight: 700, color: score >= 75 ? '#22c55e' : score >= 50 ? '#f59e0b' : '#E01950' }}>
                              {score}
                            </span>
                          </td>
                          <td style={{ padding: '10px 12px' }}>
                            <span className={`status-badge ${status}`}>{statusLabel}</span>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div className="col-lg-4">
          <div className="chart-card">
            <div className="chart-card-header mb-3">
              <div className="chart-card-title">🚨 At Risk Developers</div>
            </div>
            {atRisk.length === 0 ? (
              <div className="custom-alert success">
                <i className="bi bi-check-circle-fill" />
                All developers are performing well!
              </div>
            ) : (
              atRisk.map(dev => (
                <div key={dev.id} className="d-flex align-items-center gap-3 mb-3 p-3" style={{ background: 'rgba(224,25,80,0.04)', borderRadius: 12, border: '1px solid rgba(224,25,80,0.1)' }}>
                  <div style={{
                    width: 38, height: 38, borderRadius: '50%',
                    background: '#E0195015',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#E01950', fontWeight: 700, fontSize: 13
                  }}>
                    {dev.name?.split(' ').map(w => w[0]).join('').slice(0, 2)}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13, color: '#27235C' }}>{dev.name}</div>
                    <div style={{ fontSize: 12, color: '#E01950' }}>Score: {dev.productivityScore ?? 0}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
