package com.devdash.repository;

import com.devdash.entity.PullRequest;
import com.devdash.entity.Repository;
import com.devdash.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

@org.springframework.stereotype.Repository
public interface PullRequestRepository extends JpaRepository<PullRequest, Long> {
    List<PullRequest> findByRepository(Repository repository);
    List<PullRequest> findByAuthor(User author);
    List<PullRequest> findByAuthorAndStatus(User author, PullRequest.PrStatus status);

    @Query("SELECT COUNT(p) FROM PullRequest p WHERE p.author = :author AND p.status = 'MERGED'")
    Long countMergedByAuthor(@Param("author") User author);

    @Query("SELECT COUNT(p) FROM PullRequest p WHERE p.author = :author")
    Long countTotalByAuthor(@Param("author") User author);
}
