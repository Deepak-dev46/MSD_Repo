import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { jwtDecode } from 'jwt-decode'

export const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUserState] = useState(null)
  const [token, setTokenState] = useState(null)
  const [darkMode, setDarkMode] = useState(false)
  const [loading, setLoading] = useState(true)

  // Restore session from localStorage on mount
  useEffect(() => {
    const savedToken = localStorage.getItem('token')
    const savedUser = localStorage.getItem('user')
    if (savedToken && savedUser) {
      try {
        const decoded = jwtDecode(savedToken)
        const isExpired = decoded.exp * 1000 < Date.now()
        if (!isExpired) {
          setTokenState(savedToken)
          setUserState(JSON.parse(savedUser))
        } else {
          localStorage.removeItem('token')
          localStorage.removeItem('user')
        }
      } catch {
        localStorage.removeItem('token')
        localStorage.removeItem('user')
      }
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    document.body.classList.toggle('dark-mode', darkMode)
  }, [darkMode])

  const login = useCallback((userData, jwtToken) => {
    localStorage.setItem('token', jwtToken)
    localStorage.setItem('user', JSON.stringify(userData))
    setTokenState(jwtToken)
    setUserState(userData)
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setTokenState(null)
    setUserState(null)
  }, [])

  // Allow updating user data (e.g. after profile fetch)
  const setUser = useCallback((userData) => {
    setUserState(userData)
    if (userData) localStorage.setItem('user', JSON.stringify(userData))
  }, [])

  return (
    <AuthContext.Provider value={{ user, token, darkMode, setDarkMode, login, logout, setUser, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
