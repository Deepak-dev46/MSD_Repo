package com.devdash.repository;

import com.devdash.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByGithubId(String githubId);
    Optional<User> findByGithubUsername(String githubUsername);
    List<User> findByRole(User.Role role);
    boolean existsByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.role = 'DEVELOPER' AND u.isActive = true ORDER BY u.productivityScore DESC")
    List<User> findTopDevelopersByScore();

    @Query("SELECT u FROM User u WHERE u.role = 'DEVELOPER' AND (u.productivityScore IS NULL OR u.productivityScore < 50)")
    List<User> findLowPerformingDevelopers();
}
