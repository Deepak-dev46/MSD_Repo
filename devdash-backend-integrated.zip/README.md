# DevDash — Integrated Full-Stack Application

Developer Productivity Dashboard: Spring Boot backend + React (Vite) frontend, fully integrated with JWT authentication and role-based authorization.

---

## Architecture

```
devdash-backend/   ← Spring Boot 3.2, Java 17, MySQL, JWT, GitHub OAuth2
devdash-frontend/  ← React 18, Vite, Axios (JWT interceptors), Bootstrap 5
```

**Auth flow:**
- Manager → `POST /api/auth/login` → receives JWT → stored in `localStorage`
- Developer → GitHub OAuth2 → Spring redirects to `/oauth2/callback?token=...` → frontend stores JWT
- Every API request carries `Authorization: Bearer <token>` via Axios interceptor
- 401 responses auto-redirect to `/login`
- Routes are protected by role: `DEVELOPER` can only reach `/developer/*`, `MANAGER` can reach `/manager/*`

---

## Quick Start

### 1. Database (MySQL)
```sql
CREATE DATABASE devdash_db;
```

### 2. Backend
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.password=YOUR_MYSQL_PASSWORD

# GitHub OAuth2 (create app at github.com/settings/developers)
spring.security.oauth2.client.registration.github.client-id=YOUR_CLIENT_ID
spring.security.oauth2.client.registration.github.client-secret=YOUR_CLIENT_SECRET

# GitHub personal access token for repo sync
github.api.token=YOUR_GITHUB_PAT
```

```bash
cd devdash-backend
mvn spring-boot:run
# Backend runs on http://localhost:8080
```

### 3. Frontend
```bash
cd devdash-frontend
npm install
npm run dev
# Frontend runs on http://localhost:3000
```

### 4. Register Your First Manager
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Sarah Johnson","email":"manager@devdash.io","password":"password123","role":"MANAGER"}'
```
Then log in at http://localhost:3000 with those credentials.

---

## API Reference

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/api/auth/login` | Public | Email/password login |
| POST | `/api/auth/register` | Public | Register user |
| POST | `/api/auth/refresh` | Public | Refresh JWT |
| GET | `/api/users/me` | Auth | Current user profile |
| GET | `/api/users/developers` | MANAGER | All developers |
| GET | `/api/users/at-risk` | MANAGER | Low-performing devs |
| GET | `/api/repos` | Auth | My repositories |
| POST | `/api/repos/sync` | Auth | Sync from GitHub |
| GET | `/api/metrics/me` | Auth | My metrics |
| GET | `/api/metrics/me/weekly` | Auth | 7-day commit activity |
| GET | `/api/metrics/team` | MANAGER | Team-wide metrics |
| GET | `/api/metrics/leaderboard` | MANAGER | Productivity leaderboard |
| GET | `/api/teams` | MANAGER | All teams |
| POST | `/api/teams` | MANAGER | Create team |
| POST | `/api/teams/{id}/members/{uid}` | MANAGER | Add member |
| DELETE | `/api/teams/{id}/members/{uid}` | MANAGER | Remove member |
| POST | `/api/webhook/github` | Public | GitHub webhook receiver |

---

## GitHub OAuth2 Setup

1. Go to https://github.com/settings/developers → **OAuth Apps** → **New OAuth App**
2. **Homepage URL**: `http://localhost:3000`
3. **Callback URL**: `http://localhost:8080/login/oauth2/code/github`
4. Copy Client ID and Client Secret into `application.properties`

## GitHub Webhook Setup (for CI/CD monitoring)

1. Go to your repo → **Settings → Webhooks → Add webhook**
2. **Payload URL**: `https://your-domain/api/webhook/github`
3. **Content type**: `application/json`
4. **Events**: Select `Workflow runs`, `Push`, `Pull requests`

---

## Tech Stack

**Backend:**
- Spring Boot 3.2, Java 17
- Spring Security (JWT + OAuth2)
- Spring Data JPA / Hibernate
- MySQL 8+
- JJWT 0.11.5
- Spring WebFlux (GitHub API client)
- No Lombok — all manual getters/setters/builders

**Frontend:**
- React 18 + Vite 5
- React Router v6 (protected routes)
- Axios with JWT interceptors
- Chart.js + react-chartjs-2
- Bootstrap 5 + Bootstrap Icons
- react-hot-toast
