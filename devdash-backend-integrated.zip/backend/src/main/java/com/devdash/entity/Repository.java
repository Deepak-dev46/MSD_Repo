package com.devdash.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "repositories")
public class Repository {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "repo_name", nullable = false)
    private String repoName;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "description", length = 1000)
    private String description;

    @Column
    private String language;

    @Column(name = "stars_count")
    private Integer starsCount = 0;

    @Column(name = "forks_count")
    private Integer forksCount = 0;

    @Column(name = "open_issues_count")
    private Integer openIssuesCount = 0;

    @Column(name = "is_private")
    private Boolean isPrivate = false;

    @Column(name = "default_branch")
    private String defaultBranch = "main";

    @Column(name = "html_url")
    private String htmlUrl;

    @Column(name = "last_commit_at")
    private LocalDateTime lastCommitAt;

    @OneToMany(mappedBy = "repository", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Commit> commits;

    @OneToMany(mappedBy = "repository", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<PullRequest> pullRequests;

    @OneToMany(mappedBy = "repository", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ActionsData> actionsData;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public Repository() {}

    // Getters
    public Long getId() { return id; }
    public User getUser() { return user; }
    public String getRepoName() { return repoName; }
    public String getFullName() { return fullName; }
    public String getDescription() { return description; }
    public String getLanguage() { return language; }
    public Integer getStarsCount() { return starsCount; }
    public Integer getForksCount() { return forksCount; }
    public Integer getOpenIssuesCount() { return openIssuesCount; }
    public Boolean getIsPrivate() { return isPrivate; }
    public String getDefaultBranch() { return defaultBranch; }
    public String getHtmlUrl() { return htmlUrl; }
    public LocalDateTime getLastCommitAt() { return lastCommitAt; }
    public List<Commit> getCommits() { return commits; }
    public List<PullRequest> getPullRequests() { return pullRequests; }
    public List<ActionsData> getActionsData() { return actionsData; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setUser(User user) { this.user = user; }
    public void setRepoName(String repoName) { this.repoName = repoName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setDescription(String description) { this.description = description; }
    public void setLanguage(String language) { this.language = language; }
    public void setStarsCount(Integer starsCount) { this.starsCount = starsCount; }
    public void setForksCount(Integer forksCount) { this.forksCount = forksCount; }
    public void setOpenIssuesCount(Integer openIssuesCount) { this.openIssuesCount = openIssuesCount; }
    public void setIsPrivate(Boolean isPrivate) { this.isPrivate = isPrivate; }
    public void setDefaultBranch(String defaultBranch) { this.defaultBranch = defaultBranch; }
    public void setHtmlUrl(String htmlUrl) { this.htmlUrl = htmlUrl; }
    public void setLastCommitAt(LocalDateTime lastCommitAt) { this.lastCommitAt = lastCommitAt; }
    public void setCommits(List<Commit> commits) { this.commits = commits; }
    public void setPullRequests(List<PullRequest> pullRequests) { this.pullRequests = pullRequests; }
    public void setActionsData(List<ActionsData> actionsData) { this.actionsData = actionsData; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private User user;
        private String repoName;
        private String fullName;
        private String description;
        private String language;
        private Integer starsCount = 0;
        private Integer forksCount = 0;
        private Integer openIssuesCount = 0;
        private Boolean isPrivate = false;
        private String defaultBranch = "main";
        private String htmlUrl;
        private LocalDateTime lastCommitAt;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder user(User user) { this.user = user; return this; }
        public Builder repoName(String repoName) { this.repoName = repoName; return this; }
        public Builder fullName(String fullName) { this.fullName = fullName; return this; }
        public Builder description(String description) { this.description = description; return this; }
        public Builder language(String language) { this.language = language; return this; }
        public Builder starsCount(Integer starsCount) { this.starsCount = starsCount; return this; }
        public Builder forksCount(Integer forksCount) { this.forksCount = forksCount; return this; }
        public Builder openIssuesCount(Integer openIssuesCount) { this.openIssuesCount = openIssuesCount; return this; }
        public Builder isPrivate(Boolean isPrivate) { this.isPrivate = isPrivate; return this; }
        public Builder defaultBranch(String defaultBranch) { this.defaultBranch = defaultBranch; return this; }
        public Builder htmlUrl(String htmlUrl) { this.htmlUrl = htmlUrl; return this; }
        public Builder lastCommitAt(LocalDateTime lastCommitAt) { this.lastCommitAt = lastCommitAt; return this; }

        public Repository build() {
            Repository r = new Repository();
            r.id = id; r.user = user; r.repoName = repoName; r.fullName = fullName;
            r.description = description; r.language = language;
            r.starsCount = starsCount; r.forksCount = forksCount;
            r.openIssuesCount = openIssuesCount; r.isPrivate = isPrivate;
            r.defaultBranch = defaultBranch; r.htmlUrl = htmlUrl;
            r.lastCommitAt = lastCommitAt;
            return r;
        }
    }
}
