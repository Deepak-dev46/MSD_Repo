package com.devdash.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @Column
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Column(name = "github_id")
    private String githubId;

    @Column(name = "github_username")
    private String githubUsername;

    @Column(name = "avatar_url")
    private String avatarUrl;

    @Column(name = "access_token", length = 1000)
    private String accessToken;

    @Column(name = "productivity_score")
    private Integer productivityScore;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Repository> repositories;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum Role {
        DEVELOPER, MANAGER, ADMIN
    }

    // No-arg constructor
    public User() {}

    // All-args constructor
    public User(Long id, String name, String email, String password, Role role,
                String githubId, String githubUsername, String avatarUrl,
                String accessToken, Integer productivityScore, Boolean isActive,
                List<Repository> repositories, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.githubId = githubId;
        this.githubUsername = githubUsername;
        this.avatarUrl = avatarUrl;
        this.accessToken = accessToken;
        this.productivityScore = productivityScore;
        this.isActive = isActive;
        this.repositories = repositories;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public Role getRole() { return role; }
    public String getGithubId() { return githubId; }
    public String getGithubUsername() { return githubUsername; }
    public String getAvatarUrl() { return avatarUrl; }
    public String getAccessToken() { return accessToken; }
    public Integer getProductivityScore() { return productivityScore; }
    public Boolean getIsActive() { return isActive; }
    public List<Repository> getRepositories() { return repositories; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    // Setters
    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(Role role) { this.role = role; }
    public void setGithubId(String githubId) { this.githubId = githubId; }
    public void setGithubUsername(String githubUsername) { this.githubUsername = githubUsername; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }
    public void setAccessToken(String accessToken) { this.accessToken = accessToken; }
    public void setProductivityScore(Integer productivityScore) { this.productivityScore = productivityScore; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    public void setRepositories(List<Repository> repositories) { this.repositories = repositories; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    // Builder
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private String name;
        private String email;
        private String password;
        private Role role;
        private String githubId;
        private String githubUsername;
        private String avatarUrl;
        private String accessToken;
        private Integer productivityScore;
        private Boolean isActive = true;
        private List<Repository> repositories;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder name(String name) { this.name = name; return this; }
        public Builder email(String email) { this.email = email; return this; }
        public Builder password(String password) { this.password = password; return this; }
        public Builder role(Role role) { this.role = role; return this; }
        public Builder githubId(String githubId) { this.githubId = githubId; return this; }
        public Builder githubUsername(String githubUsername) { this.githubUsername = githubUsername; return this; }
        public Builder avatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; return this; }
        public Builder accessToken(String accessToken) { this.accessToken = accessToken; return this; }
        public Builder productivityScore(Integer productivityScore) { this.productivityScore = productivityScore; return this; }
        public Builder isActive(Boolean isActive) { this.isActive = isActive; return this; }
        public Builder repositories(List<Repository> repositories) { this.repositories = repositories; return this; }

        public User build() {
            User u = new User();
            u.id = id; u.name = name; u.email = email; u.password = password;
            u.role = role; u.githubId = githubId; u.githubUsername = githubUsername;
            u.avatarUrl = avatarUrl; u.accessToken = accessToken;
            u.productivityScore = productivityScore; u.isActive = isActive;
            u.repositories = repositories;
            return u;
        }
    }
}
