package com.devdash.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "commits")
public class Commit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repo_id", nullable = false)
    private Repository repository;

    @Column(name = "commit_sha", length = 40)
    private String commitSha;

    @Column(name = "commit_message", length = 500)
    private String commitMessage;

    @Column(name = "commit_count")
    private Integer commitCount = 1;

    @Column(name = "additions")
    private Integer additions = 0;

    @Column(name = "deletions")
    private Integer deletions = 0;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "committed_at")
    private LocalDateTime committedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id")
    private User author;

    public Commit() {}

    public Long getId() { return id; }
    public Repository getRepository() { return repository; }
    public String getCommitSha() { return commitSha; }
    public String getCommitMessage() { return commitMessage; }
    public Integer getCommitCount() { return commitCount; }
    public Integer getAdditions() { return additions; }
    public Integer getDeletions() { return deletions; }
    public LocalDate getDate() { return date; }
    public LocalDateTime getCommittedAt() { return committedAt; }
    public User getAuthor() { return author; }

    public void setId(Long id) { this.id = id; }
    public void setRepository(Repository repository) { this.repository = repository; }
    public void setCommitSha(String commitSha) { this.commitSha = commitSha; }
    public void setCommitMessage(String commitMessage) { this.commitMessage = commitMessage; }
    public void setCommitCount(Integer commitCount) { this.commitCount = commitCount; }
    public void setAdditions(Integer additions) { this.additions = additions; }
    public void setDeletions(Integer deletions) { this.deletions = deletions; }
    public void setDate(LocalDate date) { this.date = date; }
    public void setCommittedAt(LocalDateTime committedAt) { this.committedAt = committedAt; }
    public void setAuthor(User author) { this.author = author; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private Repository repository;
        private String commitSha;
        private String commitMessage;
        private Integer commitCount = 1;
        private Integer additions = 0;
        private Integer deletions = 0;
        private LocalDate date;
        private LocalDateTime committedAt;
        private User author;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder repository(Repository repository) { this.repository = repository; return this; }
        public Builder commitSha(String commitSha) { this.commitSha = commitSha; return this; }
        public Builder commitMessage(String commitMessage) { this.commitMessage = commitMessage; return this; }
        public Builder commitCount(Integer commitCount) { this.commitCount = commitCount; return this; }
        public Builder additions(Integer additions) { this.additions = additions; return this; }
        public Builder deletions(Integer deletions) { this.deletions = deletions; return this; }
        public Builder date(LocalDate date) { this.date = date; return this; }
        public Builder committedAt(LocalDateTime committedAt) { this.committedAt = committedAt; return this; }
        public Builder author(User author) { this.author = author; return this; }

        public Commit build() {
            Commit c = new Commit();
            c.id = id; c.repository = repository; c.commitSha = commitSha;
            c.commitMessage = commitMessage; c.commitCount = commitCount;
            c.additions = additions; c.deletions = deletions; c.date = date;
            c.committedAt = committedAt; c.author = author;
            return c;
        }
    }
}
