import React, { useState, useEffect } from 'react'
import { Bar, Line } from 'react-chartjs-2'
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend, Filler } from 'chart.js'
import { metricsApi, userApi } from '../../services/api'
import toast from 'react-hot-toast'

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend, Filler)

export default function ReportsPage() {
  const [teamMetrics, setTeamMetrics] = useState(null)
  const [leaderboard, setLeaderboard] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([metricsApi.team(), metricsApi.leaderboard()])
      .then(([tRes, lRes]) => { setTeamMetrics(tRes.data); setLeaderboard(lRes.data) })
      .catch(() => toast.error('Failed to load reports'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="d-flex align-items-center justify-content-center" style={{ height: '60vh' }}>
      <div className="spinner-border" style={{ color: '#97247E' }} />
    </div>
  )

  const devs = teamMetrics?.developers || []

  const commitsBarData = {
    labels: devs.slice(0, 10).map(d => d.name?.split(' ')[0]),
    datasets: [{
      label: 'Commits',
      data: devs.slice(0, 10).map(d => d.commits),
      backgroundColor: '#27235C',
      borderRadius: 8,
    }]
  }

  const prsBarData = {
    labels: devs.slice(0, 10).map(d => d.name?.split(' ')[0]),
    datasets: [{
      label: 'PRs',
      data: devs.slice(0, 10).map(d => d.prs),
      backgroundColor: '#97247E',
      borderRadius: 8,
    }]
  }

  const scoresLineData = {
    labels: leaderboard.map(d => d.name?.split(' ')[0]),
    datasets: [{
      label: 'Productivity Score',
      data: leaderboard.map(d => d.score),
      fill: true,
      backgroundColor: 'rgba(39,35,92,0.08)',
      borderColor: '#27235C',
      borderWidth: 2.5,
      pointBackgroundColor: '#27235C',
      pointRadius: 5,
      tension: 0.4,
    }]
  }

  const chartOpts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { backgroundColor: '#27235C', padding: 12, cornerRadius: 10 } },
    scales: { x: { grid: { display: false } }, y: { grid: { color: '#f5f5f5' }, beginAtZero: true } }
  }

  const totalCommits = teamMetrics?.totalCommits ?? 0
  const totalPrs = teamMetrics?.totalPrs ?? 0
  const avgScore = devs.length > 0 ? Math.round(devs.reduce((sum, d) => sum + (d.score || 0), 0) / devs.length) : 0
  const atRisk = teamMetrics?.atRiskCount ?? 0

  return (
    <div>
      <div className="page-header">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Reports</h1>
            <p className="page-subtitle">Team performance overview and analytics.</p>
          </div>
          <button className="btn-gradient" onClick={() => window.print()}>
            <i className="bi bi-printer" /> Print Report
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="row g-3 mb-4">
        {[
          { label: 'Total Developers', value: teamMetrics?.totalDevelopers ?? 0, icon: 'bi-people', color: '#27235C' },
          { label: 'Total Commits', value: totalCommits.toLocaleString(), icon: 'bi-git', color: '#97247E' },
          { label: 'Total PRs', value: totalPrs.toLocaleString(), icon: 'bi-arrow-left-right', color: '#22c55e' },
          { label: 'Avg Score', value: avgScore, icon: 'bi-lightning-charge', color: '#f59e0b' },
          { label: 'At Risk', value: atRisk, icon: 'bi-exclamation-triangle', color: '#E01950' },
        ].map(stat => (
          <div key={stat.label} className="col-lg col-sm-6">
            <div className="chart-card text-center">
              <i className={`bi ${stat.icon}`} style={{ fontSize: 24, color: stat.color, display: 'block', marginBottom: 8 }} />
              <div style={{ fontSize: 28, fontWeight: 900, color: stat.color }}>{stat.value}</div>
              <div style={{ fontSize: 12, color: '#aaa', marginTop: 4 }}>{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      {devs.length === 0 ? (
        <div className="chart-card text-center py-5">
          <i className="bi bi-bar-chart" style={{ fontSize: 48, color: '#ddd', display: 'block', marginBottom: 16 }} />
          <p style={{ color: '#aaa' }}>No developer data yet. Developers need to log in and sync their GitHub repositories.</p>
        </div>
      ) : (
        <>
          <div className="row g-3 mb-4">
            <div className="col-lg-6">
              <div className="chart-card">
                <div className="chart-card-title mb-1">Commits by Developer</div>
                <div className="chart-card-sub mb-3">All-time total commits</div>
                <div style={{ height: 260 }}>
                  <Bar data={commitsBarData} options={chartOpts} />
                </div>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="chart-card">
                <div className="chart-card-title mb-1">Pull Requests by Developer</div>
                <div className="chart-card-sub mb-3">All-time total PRs</div>
                <div style={{ height: 260 }}>
                  <Bar data={prsBarData} options={chartOpts} />
                </div>
              </div>
            </div>
          </div>

          {leaderboard.length > 0 && (
            <div className="chart-card mb-4">
              <div className="chart-card-title mb-1">Productivity Score Trend</div>
              <div className="chart-card-sub mb-3">Top performers ranked by score</div>
              <div style={{ height: 260 }}>
                <Line data={scoresLineData} options={{ ...chartOpts, plugins: { ...chartOpts.plugins, legend: { display: false } } }} />
              </div>
            </div>
          )}

          {/* Leaderboard table */}
          <div className="chart-card">
            <div className="chart-card-title mb-4">🏆 Productivity Leaderboard</div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #f0f0f0' }}>
                  {['#', 'Developer', 'Score', 'Status'].map(h => (
                    <th key={h} style={{ padding: '8px 12px', textAlign: 'left', color: '#aaa', fontWeight: 600, fontSize: 12 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {leaderboard.map((dev, i) => {
                  const score = dev.score ?? 0
                  const medals = ['🥇', '🥈', '🥉']
                  return (
                    <tr key={dev.id} style={{ borderBottom: '1px solid #f8f8f8' }}>
                      <td style={{ padding: '10px 12px', fontWeight: 700, color: '#27235C' }}>
                        {i < 3 ? medals[i] : `#${i + 1}`}
                      </td>
                      <td style={{ padding: '10px 12px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{
                            width: 30, height: 30, borderRadius: '50%',
                            background: 'linear-gradient(135deg,#27235C,#97247E)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            color: 'white', fontSize: 11, fontWeight: 700
                          }}>
                            {dev.name?.split(' ').map(w => w[0]).join('').slice(0, 2)}
                          </div>
                          <span style={{ fontWeight: 600 }}>{dev.name}</span>
                        </div>
                      </td>
                      <td style={{ padding: '10px 12px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{ flex: 1, height: 6, background: '#f0f0f0', borderRadius: 3, maxWidth: 120 }}>
                            <div style={{ height: '100%', borderRadius: 3, width: `${score}%`, background: score >= 75 ? '#22c55e' : score >= 50 ? '#f59e0b' : '#E01950' }} />
                          </div>
                          <span style={{ fontWeight: 800, color: score >= 75 ? '#22c55e' : score >= 50 ? '#f59e0b' : '#E01950' }}>
                            {score}
                          </span>
                        </div>
                      </td>
                      <td style={{ padding: '10px 12px' }}>
                        <span className={`status-badge ${score >= 75 ? 'success' : score >= 50 ? 'warning' : 'danger'}`}>
                          {score >= 75 ? 'Top Performer' : score >= 50 ? 'Average' : 'At Risk'}
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}
