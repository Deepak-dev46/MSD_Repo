package com.devdash.repository;

import com.devdash.entity.Repository;
import com.devdash.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

@org.springframework.stereotype.Repository
public interface RepositoryRepository extends JpaRepository<Repository, Long> {
    List<Repository> findByUser(User user);
    Optional<Repository> findByUserAndRepoName(User user, String repoName);
    Optional<Repository> findByFullName(String fullName);
    List<Repository> findByUserOrderByLastCommitAtDesc(User user);
}
